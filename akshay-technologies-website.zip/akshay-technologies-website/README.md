# Akshay Technologies Website

Deployable static HTML/CSS/JS portfolio website.

Before publishing:
1. Open `script.js` and replace each `play:'#'` with the real public Google Play Store URL for that app.
2. Replace `hello@akshaytechnologies.example` in `index.html` with the real business email.
3. Make descriptions/features match the exact functionality of the live apps.
4. Upload the folder to GitHub Pages, Netlify, Vercel, Cloudflare Pages, or your own static hosting.
5. Put the final public website URL in the Google Business Profile website field.
